package com.example.zulqarnain.locationservice;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Zul Qarnain on 9/19/2017.
 */

public class Person {
    @SerializedName("uid")
    String uid;
    @SerializedName("latitude")
    String latitude;

}
